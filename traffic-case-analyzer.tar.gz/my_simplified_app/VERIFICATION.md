# 部署验证步骤

## Windows 系统兼容性检查

1. 检查端口可用性
   ```cmd
   netstat -ano | findstr LISTENING | findstr "5000"
   ```
   如果端口被占用，您会看到类似以下输出：
   ```
   TCP    127.0.0.1:5000    0.0.0.0:0    LISTENING    1234
   ```
   此时需要使用以下命令关闭占用端口的进程：
   ```cmd
   taskkill /PID 1234 /F
   ```

2. 文件路径兼容性
   - 所有路径使用相对路径或os.path进行处理
   - 数据文件位于 `data/cases.json`
   - 静态文件位于 `app/static/index.html`
   - Python文件使用跨平台兼容的路径分隔符

## 本地部署验证

1. 环境设置
   ```cmd
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   ```

2. 启动应用
   ```cmd
   python app.py
   ```
   应看到以下输出：
   ```
   * Running on http://127.0.0.1:5000
   * Debug mode: on
   ```

3. 验证清单
   - [ ] 服务器成功启动在127.0.0.1:5000
   - [ ] 浏览器能访问http://127.0.0.1:5000
   - [ ] 能输入案例并获得分析结果
   - [ ] 显示相似案例和相关法条
   - [ ] 所有功能在断开互联网的情况下仍能正常工作

## 离线运行确认

本应用设计为完全离线运行：
1. 所有数据存储在本地data/cases.json
2. 不需要外部API或互联网连接
3. 所有依赖包都在requirements.txt中列出
4. 分析逻辑完全在本地执行

## 故障排除

如果遇到问题：
1. 确保端口5000未被占用
2. 确保已安装所有依赖包
3. 检查data/cases.json文件存在且格式正确
4. 确保Python版本为3.6或更高版本

如有任何问题，请查看错误信息并对照上述步骤进行检查。
